package com.greenhat.medibook;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



public class Logout extends android.app.Fragment {



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Intent intent=new Intent(getActivity().getBaseContext(),Login.class);
        startActivity(intent);
        return inflater.inflate(R.layout.fragment_logout,container,false);
    }


}
