package com.greenhat.medibook;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Calendar;


public class Reports extends android.app.Fragment {
    ListView l1;
    Button b3;
    SQLiteDatabase db,db2;int d=0;
    String name2;
    String tokens[],treatm[],hospita[];
    int c3[];
    final String emle=Globe.emlr;
    final String emls=Globe.emlw;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_reports, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        l1=(ListView)getActivity().findViewById(R.id.lt4);

        b3=(Button)getActivity().findViewById(R.id.tr);
        database database11=new database(getActivity().getBaseContext(),"patientdb",null,3);
        db2=database11.getWritableDatabase();
        database database12=new database(getActivity().getBaseContext(),"hospitaldb",null,3);
        db=database12.getWritableDatabase();
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),emle,Toast.LENGTH_SHORT).show();
                Toast.makeText(getActivity(),emls,Toast.LENGTH_SHORT).show();


                Cursor c=null;
                c=db2.rawQuery("select NAME from patient where EMAIL='"+emle+"'",null);

                if (c.moveToNext())
                {
                    name2 = c.getString(0);
                }
                Cursor cr=null;
                cr=db2.rawQuery("select TOKE_NO,TREATMENT,HOSP from patient1 "+" where PATIENT_NAME='"+name2+"'",null);
                int x=cr.getCount();
                tokens=new String[x];
                treatm=new String[x];
                hospita=new String[x];
                c3=new int[x];
                for(int i=0;i<x;i++){
                    c3[i]=i+1;
                }
                if(cr.moveToFirst()) {
                    do {
                        tokens[d] = cr.getString(0);
                        treatm[d] = cr.getString(1);
                        hospita[d]=cr.getString(2);
                        d++;
                    }
                    while (cr.moveToNext());
                }
                custadap c8= new custadap(getActivity().getBaseContext(),tokens,treatm,hospita,c3);
                l1.setAdapter(c8);
            }
        });
    }

}
