package com.greenhat.medibook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.Calendar;

/**
 * Created by priyanshu on 20/6/16.
 */

public class custadap extends BaseAdapter {
   Context c;
    int c1;
    String tokens[],treatm[],hospita[];
    int c3[];

    @Override
    public int getCount() {
        return treatm.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater l1=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=l1.inflate(R.layout.layoutre,null);


        TextView tv=(TextView) convertView.findViewById(R.id.lt2);
        TextView tv1=(TextView)convertView.findViewById(R.id.lt1);
        TextView tv2=(TextView)convertView.findViewById(R.id.lt) ;
        TextView dt=(TextView)convertView.findViewById(R.id.dte);
        tv.setText(tokens[position]);
        tv1.setText(treatm[position]);
        tv2.setText(hospita[position]);
        dt.setInputType(c3[position]);

        return convertView;
    }
    custadap(Context c,String[] tokens,String[] treatm,String[] hospita ,int[] c3)
    {
        this.c=c;
        this.tokens=tokens;
        this.treatm=treatm;
        this.hospita=hospita;
        this.c3=c3;
    }
}
