package com.greenhat.medibook;

/**
 * Created by priyanshu on 20/6/16.
 */

public class Globe {
    static String eml;
    static String hosp;
    static String emlr;
    static String emlw;
}
