package com.greenhat.medibook;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import static com.greenhat.medibook.R.layout.support_simple_spinner_dropdown_item;


public class Contact extends android.app.Fragment {
    AutoCompleteTextView t1,t2;Button bn;Spinner sp;String f;
    final String [] are={"kharar","chandigarh","amritsar"};
    final   String [] hospk={"civil","Mehta","kaushal"};
    final String []hospchd={"Government_Multi_SpecialityHospital","JPHospital","SangamNeuroHospital","Omni_Hospital","Dharam_Hospital"};
    final String []hospam={"Amandeep_Hospital","Sri _GuruNanakDev_Hospital","Kalra_Hospital","Nayyar_Hospital","Madaan _Hospital"};
    final String []numb={"14256","47856","89632","12563"};
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contact, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        t1=(AutoCompleteTextView)getActivity().findViewById(R.id.area1);
        t2=(AutoCompleteTextView)getActivity().findViewById(R.id.hosp);
        sp=(Spinner) getActivity().findViewById(R.id.treat);
        bn=(Button)getActivity().findViewById(R.id.btnn);

        final ArrayAdapter<String> are2=new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item,are);
        t1.setAdapter(are2);
        final ArrayAdapter<String> are3=new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item,are);
        sp.setAdapter(are3);

        t1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String c= are2.getItem(position).toString();
                if(c.equals("kharar")) {
                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item,hospk);
                    t2.setAdapter(ar);
                    t2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    });

                }
                else if(c.equals("chandigarh")){
                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item, hospchd);
                    t2.setAdapter(ar);
                }
                else
                {
                    ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item, hospam);
                    t2.setAdapter(ar);
                }
            }
        });
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String s3=sp.getSelectedItem().toString();
                Intent i6= new Intent(Intent.ACTION_CALL);
                i6.setData(Uri.parse("tel:"+s3));
                try{
                    startActivity(i6);
                }

                catch (android.content.ActivityNotFoundException ex){
                    Toast.makeText(getActivity(),"yourActivity is not founded",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
