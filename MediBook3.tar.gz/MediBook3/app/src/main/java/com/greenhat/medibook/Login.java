package com.greenhat.medibook;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.id;

public class Login extends AppCompatActivity {
    TextView textView;
    EditText e1,e2;
    String eml,pass,pass1,idn;
    Button b1;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        textView=(TextView)findViewById(R.id.nwusr);
        e1=(EditText)findViewById(R.id.emails);
        e2=(EditText)findViewById(R.id.erpass);
        b1=(Button)findViewById(R.id.btnl);

        textView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Intent signup1=new Intent(Login.this,SignUp.class);
                startActivity(signup1);
                return false;
            }
        });

        database database4=new database(getApplicationContext(),"patientdb",null,3);
        db=database4.getWritableDatabase();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eml = e1.getText().toString();
                Globe.eml=eml;
                pass = e2.getText().toString();

                Cursor c=null;
               c=db.rawQuery("select PASSWORD,IDPH from patient where EMAIL='"+eml+"'",null);

                if (c.moveToNext())
                {
                    pass1 = c.getString(0);
                    idn = c.getString(1);
                }
           if (pass.equals(pass1))
           {

                    if (idn.equals("Patient")) {
                        Intent i7 = new Intent(Login.this, Patient.class);
                        startActivity(i7);
                    } else {


                        Intent i7 = new Intent(Login.this, HospitalEntry.class);
                        startActivity(i7);
                    }

           }

           else
           {
                    Toast.makeText(getApplicationContext(), "wrong credentials", Toast.LENGTH_SHORT).show();
           }


            }
        });


    }


}
