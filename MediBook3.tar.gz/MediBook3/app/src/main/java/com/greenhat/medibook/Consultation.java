package com.greenhat.medibook;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import static android.R.attr.password;
import static com.greenhat.medibook.R.layout.support_simple_spinner_dropdown_item;


public class Consultation extends android.app.Fragment {
AutoCompleteTextView t1,t2,t3;Button bn;
    final String [] are={"kharar","chandigarh","amritsar"};
  final   String [] hospk={"civil","Mehta","kaushal"};
    final String []hospchd={"Government_Multi_SpecialityHospital","JPHospital","SangamNeuroHospital","Omni_Hospital","Dharam_Hospital"};
    final String []hospam={"Amandeep_Hospital","Sri _GuruNanakDev_Hospital","Kalra_Hospital","Nayyar_Hospital","Madaan _Hospital"};
    final String []Treatment={"ENT","Gynaecology",};
    SQLiteDatabase db,db1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_consultation, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        t1=(AutoCompleteTextView)getActivity().findViewById(R.id.area1);
        t2=(AutoCompleteTextView)getActivity().findViewById(R.id.hosp);
        t3=(AutoCompleteTextView)getActivity().findViewById(R.id.treat);
        bn=(Button)getActivity().findViewById(R.id.btnn);
        final ArrayAdapter<String> treat=new ArrayAdapter<String>(getActivity(),support_simple_spinner_dropdown_item,Treatment);
        t3.setAdapter(treat);
       final ArrayAdapter<String> are1=new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item,are);
        t1.setAdapter(are1);
        database database3=new database(getActivity(),"hospitaldb",null,3);
        db=database3.getReadableDatabase();
        database database4=new database(getActivity(),"patientdb",null,3);
        db1=database4.getReadableDatabase();
       t1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               String c= are1.getItem(position).toString();
               if(c.equals("kharar")) {
                   ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item, hospk);
                   t2.setAdapter(ar);
               }
               else if(c.equals("chandigarh")){
                   ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item, hospchd);
                   t2.setAdapter(ar);
               }
               else
               {
                   ArrayAdapter<String> ar = new ArrayAdapter<String>(getActivity(), R.layout.support_simple_spinner_dropdown_item, hospam);
                   t2.setAdapter(ar);
               }
           }
       });
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db=getActivity().openOrCreateDatabase("hospitaldb",Context.MODE_PRIVATE,null);
                db1=getActivity().openOrCreateDatabase("patientdb",Context.MODE_PRIVATE,null);
                String hs=t2.getText().toString();
                String eml=Globe.eml;

                String ht=t3.getText().toString();
                String ht5=t1.getText().toString();

                String pa=null;
                Cursor c=null;
                c=db1.rawQuery("select NAME from patient where EMAIL='"+eml+"'",null);

                if (c.moveToNext())
                {
                    pa = c.getString(0);
                }
               Globe.emlr=pa;
                Globe.emlw=hs;

                db.execSQL("create table if not exists "+hs+" "+"(AREA TEXT,HOSP TEXT,PATIENT_NAME TEXT,TREATMENT TEXT,TOKE_NO INTEGER PRIMARY KEY AUTOINCREMENT)");
                db1.execSQL("create table if not exists patient1 (AREA TEXT,HOSP TEXT,PATIENT_NAME TEXT,TREATMENT TEXT,TOKE_NO INTEGER PRIMARY KEY AUTOINCREMENT)");

                if(hs.equals("") ||ht.equals("") || c.equals("")){
                    Toast.makeText(getActivity(),"Enter Full Details",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getActivity().getBaseContext(),pa,Toast.LENGTH_SHORT).show();
                    ContentValues cr=new ContentValues();
                    cr.put("AREA",ht5);
                    cr.put("HOSP",hs);
                    cr.put("PATIENT_NAME",pa);
                    cr.put("TREATMENT",ht);


                  long  l1=db.insert(hs,null,cr);
                    ContentValues cp=new ContentValues();
                    cp.put("AREA",ht5);
                    cp.put("HOSP",hs);
                    cp.put("PATIENT_NAME",pa);
                    cp.put("TREATMENT",ht);
                    long l2=db1.insert("patient1",null,cp);

                    if(l1>0 && l2>0){

                        Toast.makeText(getActivity(),"Registered",Toast.LENGTH_LONG).show();

                    }
                    else
                    {
                        Toast.makeText(getActivity(),"email user already exists",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

    }


}

