package com.greenhat.medibook;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {
    Button button;ImageView imageView;RadioGroup radioGroup;RadioButton radioButton;
    EditText ed1,ed2,ed3,ed4;
    String name,email,password,identity;
    SQLiteDatabase db;
    long l1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sign_up);
        button=(Button)findViewById(R.id.signup);
        ed1=(EditText) findViewById(R.id.nme);
        ed2=(EditText) findViewById(R.id.n0);
        ed3=(EditText) findViewById(R.id.pssd);
        ed4=(EditText) findViewById(R.id.pssd2);
        imageView=(ImageView)findViewById(R.id.im3);
        radioGroup=(RadioGroup)findViewById(R.id.rdi);



        database database2=new database(getApplicationContext(),"patientdb",null,3);
        db=database2.getWritableDatabase();

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    name = ed1.getText().toString();
                    email = ed2.getText().toString();
                    password = ed3.getText().toString();
                    try {
                    int selected = radioGroup.getCheckedRadioButtonId();
                    radioButton = (RadioButton) findViewById(selected);
                    identity = radioButton.getText().toString();
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }

                    if (name.equals("") || email.equals("") || password.equals("")) {
                        Toast.makeText(getApplicationContext(), "Enter Full Details", Toast.LENGTH_SHORT).show();
                    } else {
                        ContentValues cr = new ContentValues();
                        cr.put("NAME", name);
                        cr.put("PASSWORD", password);
                        cr.put("IDPH", identity);
                        cr.put("EMAIL", email);

                        l1 = db.insert("patient", null, cr);
                        if (l1 > 0) {

                            Toast.makeText(getApplicationContext(), "Registered", Toast.LENGTH_LONG).show();
                            Intent i4 = new Intent(SignUp.this, Login.class);
                            startActivity(i4);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "email user already exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

    }
}
