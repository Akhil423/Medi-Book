package com.greenhat.medibook;

import android.content.Intent;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HospitalEntry extends AppCompatActivity  {
SQLiteDatabase db;
    EditText e4,e5;Button b8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_entry);
        e4=(EditText)findViewById(R.id.are2);
        e5=(EditText)findViewById(R.id.hos3);
        b8=(Button)findViewById(R.id.gt5);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i8=new Intent(HospitalEntry.this,Hospital1.class);
                String s3=e5.getText().toString();
                i8.putExtra("hosp",s3);
                startActivity(i8);
                finish();

            }
        });

    }



}
