package com.greenhat.medibook;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;


public class Home extends android.app.Fragment {

   ImageSwitcher imageSwitcher;
    int i=0;
    int a[]={R.drawable.tip1,R.drawable.tip2,R.drawable.tip3};




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_home, container, false);

    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        imageSwitcher=(ImageSwitcher) getActivity().findViewById(R.id.tr3);
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView=new ImageView(getActivity());
                return imageView;
            }
        });
        imageSwitcher.postDelayed(new Runnable() {
            @Override
            public void run() {
                imageSwitcher.setImageResource(a[i]);

                    i++;

                if(i==a.length) {
                    i=0;
                }
                imageSwitcher.postDelayed(this,3000);
            }
        },0);


        Animation in= AnimationUtils.loadAnimation(getActivity(),android.R.anim.slide_in_left);

        Animation ou= AnimationUtils.loadAnimation(getActivity(),android.R.anim.slide_out_right);

        imageSwitcher.setInAnimation(in);
        imageSwitcher.setOutAnimation(ou);


    }

}