package com.greenhat.medibook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by priyanshu on 21/6/16.
 */

public class custadap2 extends BaseAdapter {
    Context c;
    String tokens[],treatm[],patntnme[];

    @Override
    public int getCount() {
        return treatm.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater l1=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=l1.inflate(R.layout.layouthsp,null);


        TextView tv=(TextView) convertView.findViewById(R.id.lt2);
        TextView tv1=(TextView)convertView.findViewById(R.id.lt1);
        TextView tv2=(TextView)convertView.findViewById(R.id.dte) ;

        tv.setText(tokens[position]);
        tv1.setText(treatm[position]);
        tv2.setText(patntnme[position]);

        return convertView;
    }
    custadap2(Context c, String[] tokens, String[] treatm, String[] patntnme)
    {
        this.c=c;
        this.tokens=tokens;
        this.treatm=treatm;
        this.patntnme=patntnme;

    }
}

