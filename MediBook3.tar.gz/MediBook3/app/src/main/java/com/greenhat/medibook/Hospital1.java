package com.greenhat.medibook;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class Hospital1 extends AppCompatActivity {
    ListView l1;
    Button b3;
    SQLiteDatabase db;int d=0;
    String name2;
    String token[],treat[],paita[];
String hspe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital1);

        Intent it=getIntent();
        hspe=it.getStringExtra("hosp");
        setTitle(hspe);

        l1=(ListView)findViewById(R.id.lt4);

        b3=(Button)findViewById(R.id.ty6);
        database database12=new database(getApplicationContext(),"hospitaldb",null,3);
        db=database12.getWritableDatabase();
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

Cursor cr;
                cr=db.rawQuery("select TOKE_NO,TREATMENT,PATIENT_NAME from "+hspe+"",null);
                int x=cr.getCount();
                token=new String[x];
                treat=new String[x];
                paita=new String[x];

                if(cr.moveToFirst()) {
                    do {
                        token[d] = cr.getString(0);
                        treat[d] = cr.getString(1);
                        paita[d]=cr.getString(2);
                        d++;
                    }
                    while (cr.moveToNext());
                }
                custadap2 c8= new custadap2(getApplicationContext(),token,treat,paita);
                l1.setAdapter(c8);
            }
        });

    }




}
